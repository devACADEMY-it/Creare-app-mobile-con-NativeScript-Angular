import { Component, OnInit } from "@angular/core";
import {allNews, DataItem} from '~/app/News';

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    title = 'App';
    latestNews: DataItem[];
    news: DataItem;

    constructor() {
        this.latestNews = allNews;
        this.news = this.latestNews[2];
    }

    ngOnInit(): void {

    }
}
