import { Component } from "@angular/core";
import { RouterExtensions } from "nativescript-angular/router";

@Component({
    selector: "ns-app",
    templateUrl: "app.component.html"
})
export class AppComponent {

    constructor(private routerExtensions: RouterExtensions) {

    }

    gotoPlanet() {
        this.routerExtensions.navigate(['/home'], { clearHistory: true });
    }

    gotoAsteroids() {
        this.routerExtensions.navigate(['/asteroids'], { clearHistory: true });
    }
}
