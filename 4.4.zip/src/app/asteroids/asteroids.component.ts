import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'ns-asteroids',
    templateUrl: './asteroids.component.html',
    styleUrls: ['./asteroids.component.css']
})
export class AsteroidsComponent implements OnInit {

    constructor() { }

    ngOnInit(): void {
    }

}
