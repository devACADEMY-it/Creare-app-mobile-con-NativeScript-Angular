import { Component } from "@angular/core";
import { RouterExtensions } from "nativescript-angular/router";
import {ActivatedRoute} from '@angular/router';

@Component({
    selector: "ns-app",
    templateUrl: "app.component.html"
})
export class AppComponent {

    constructor(private routerExtensions: RouterExtensions, private activeRoute: ActivatedRoute) {

    }

    gotoPlanet() {
        this.routerExtensions.navigate(['/home'], { relativeTo: this.activeRoute });
    }

    gotoAsteroids() {
        this.routerExtensions.navigate(['/asteroids'], { relativeTo: this.activeRoute });
    }
}
