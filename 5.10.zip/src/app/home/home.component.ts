import { Component, OnInit } from "@angular/core";
import {allNews, DataItem} from '~/app/News';
import {NewsService} from '~/app/news.service';

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    title = 'App';
    allNews: DataItem[];
    news: DataItem[];
    searching: boolean;
    currentPage: number;

    constructor(private newsService: NewsService) {
        this.searching = false;
        this.currentPage = 1;
        this.newsService.getNews().subscribe((res: any) => {
            this.allNews = JSON.parse(JSON.stringify(res.articles));
            this.news = this.allNews;
        });
    }

    ngOnInit(): void {

    }

    getDate(item: DataItem) {
        return new Date(item.publishedAt).toLocaleDateString();
    }

    onPullToRefresh(args) {
        this.newsService.getNews().subscribe((res: any) => {
            this.allNews = JSON.parse(JSON.stringify(res.articles));
            this.news = this.allNews;
            args.object.notifyPullToRefreshFinished();
        });
    }

    onLoadMore(args) {
        this.currentPage += 1;
        this.newsService.getNews(this.currentPage).subscribe((res: any) => {
            if (res.articles.length > 0) {
                this.allNews.push(...JSON.parse(JSON.stringify(res.articles)));
                this.news = this.allNews;
                args.object.notifyLoadOnDemandFinished();
            } else {
                args.returnValue = false;
                args.object.notifyLoadOnDemandFinished(true);
            }
        });
    }

    onSubmit(args) {
        const searchText = args.object.text.toLowerCase();
        this.news = this.allNews.filter(news =>
            news.title.toLowerCase().includes(searchText) ||
            (news.description && news.description.toLowerCase().includes(searchText))
        );
        args.object.dismissSoftInput();
    }

    onClear(args) {
        this.news = this.allNews;
        this.searching = false;
        args.object.text = "";
        args.object.hint = "Filter news";
        args.object.dismissSoftInput();
    }
}
