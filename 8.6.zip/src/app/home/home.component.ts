import {Component} from "@angular/core";

interface User {
    name: string;
    age: number;
    email: string;
    city: string;
    street: string;
    streetNumber: number;
    date: string;
    time: string;
    test: string;
}

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent {
    title = 'Gestione dei form';
    user: User;
    userMetadata: any;

    constructor() {
        this.user = {
            name: "Adriano",
            age: 28,
            email: "carmhack@google.com",
            city: "Salerno",
            street: "Via Da Qui",
            streetNumber: 11,
            date: "2020-04-06",
            time: "18:00",
            test: "test"
        };
        this.userMetadata = {
            propertyAnnotations: [
                {
                    name: "name",
                    displayName: "Nome",
                    index: 0
                },
                {
                    name: "age",
                    displayName: "Età",
                    index: 1
                },
                {
                    name: "email",
                    displayName: "Email",
                    editor: "Email",
                    index: 2
                },
                {
                    name: "city",
                    displayName: "Città",
                    editor: "Picker",
                    valuesProvider: ["Salerno", "Roma", "Napoli"],
                    index: 3
                },
                {
                    name: "street",
                    displayName: "Via",
                    index: 4
                },
                {
                    name: "streetNumber",
                    displayName: "Civico",
                    index: 5
                },
                {
                    name: "date",
                    displayName: "Data",
                    editor: "DatePicker",
                    index: 6
                },
                {
                    name: "time",
                    displayName: "Ora",
                    editor: "TimePicker",
                    index: 7
                },
                {
                    name: "test",
                    displayName: "Test",
                    ignore: true,
                    index: 8
                }
            ]
        }
    }
}
