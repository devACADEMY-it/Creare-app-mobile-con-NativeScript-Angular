import { Component, OnInit } from "@angular/core";
import { ItemEventData } from "tns-core-modules/ui/list-view";

@Component({
    selector: "Home",
    templateUrl: "./home.component.html"
})
export class HomeComponent implements OnInit {
    title = 'My App';
    planets: any[];
    planetInput = "ciao";

    constructor() {
        // Use the component constructor to inject providers.
        this.planets = [
            {
                name: 'Mercurio',
                imageSrc: 'mercurio.jpg',
            },
            {
                name: 'Venere',
                imageSrc: 'venere.jpg',
            },
            {
                name: 'Terra',
                imageSrc: 'terra.jpg',
            },
            {
                name: 'Marte',
                imageSrc: 'marte.jpg',
            },
            {
                name: 'Giove',
                imageSrc: 'giove.jpg',
            },
            {
                name: 'Saturno',
                imageSrc: 'saturno.jpg',
            },
            {
                name: 'Urano',
                imageSrc: 'urano.jpg',
            },
            {
                name: 'Nettuno',
                imageSrc: 'nettuno.jpg',
            },
            {
                name: 'Plutone',
                imageSrc: 'plutone.jpg',
            }
        ]
    }

    ngOnInit(): void {
        // Init your component properties here.
    }

    getImage(planet: any): string {
        return `~/app/images/planets/${planet.imageSrc}`;
    }

    onItemTap(event: ItemEventData) {
        console.log(this.planets[event.index].name);
    }
}
