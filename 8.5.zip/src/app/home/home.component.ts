import {Component} from "@angular/core";

interface User {
    username: string;
    email: string;
    age: number;
    password: string;
    repeatPassword: string;
}

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent {
    title = 'Gestione dei form';
    user: User;

    constructor() {
        this.user = {
            username: 'carmhack',
            email: 'carmhack@gmail.com',
            age: 23,
            password: 'ciao',
            repeatPassword: 'ciao'
        }
    }
}
