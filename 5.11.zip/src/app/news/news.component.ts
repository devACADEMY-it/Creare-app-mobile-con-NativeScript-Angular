import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {DataItem} from '~/app/News';

@Component({
  selector: 'ns-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
    item: DataItem;

    constructor(private route: ActivatedRoute) {
      this.route.params.subscribe((params: any) => this.item = params)
    }

    ngOnInit(): void {
    }

    getDate(item: DataItem) {
        return new Date(item.publishedAt).toLocaleDateString();
    }
}
