import {Component, OnInit} from "@angular/core";
import {SwipeDirection} from '@nativescript/core';

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    title = 'App';
    logs = [];

    constructor() {}

    ngOnInit(): void {}

    onTap() {
        this.logs.unshift({ text: 'Hai effettuato un TAP!' });
    }

    onDoubleTap() {
        this.logs.unshift({ text: 'Hai effettuato un DOUBLE TAP!' });
    }

    onLongPress() {
        this.logs.unshift({ text: 'Hai effettuato un LONG PRESS!' });
    }

    onSwipe(args) {
        let direction = args.direction === SwipeDirection.down ? "down" :
            args.direction == SwipeDirection.up ? "up" :
            args.direction == SwipeDirection.left ? "left" : "right";

        this.logs.unshift({ text: 'Hai effettuato uno SWIPE in direzione '+direction+'!' });
    }

    onPinch() {
        this.logs.unshift({ text: 'Hai effettuato un PINCH!' });
    }

    onRotation() {
        this.logs.unshift({ text: 'Hai effettuato una ROTATION!' });
    }
}
