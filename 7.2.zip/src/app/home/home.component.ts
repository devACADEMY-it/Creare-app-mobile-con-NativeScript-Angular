import {Component, ElementRef, OnInit, ViewChild} from "@angular/core";
import { Color } from "@nativescript/core";
import { AnimationCurve  } from "tns-core-modules/ui/enums";

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent {
    @ViewChild("target", { static: true }) targetLabel: ElementRef;
    title = 'App';

    constructor() {}

    animate() {
        const target = this.targetLabel.nativeElement;
        const duration = 2000;

        target.animate({
            translate: { x: 0, y: 100 },
            duration: duration
        })
        .then(() => target.animate({
            scale: { x: 2, y: 2 },
            rotate: 360,
            curve: AnimationCurve.cubicBezier(.74,.28,.92,.15),
            duration: duration
        }))
        .then(() => target.animate({
            backgroundColor: new Color("blue"),
            duration: duration
        }))
        .then(() => console.log('ANIMAZIONE FINITA'))
        .catch(() => console.log('ERRORE ANIMAZIONE'));
    }
}
