import {Component, ElementRef, OnInit, ViewChild} from "@angular/core";

@Component({
    selector: "ns-home",
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent {
    @ViewChild("target", { static: true }) targetLabel: ElementRef;
    title = 'App';

    constructor() {}

    animate() {
        this.targetLabel.nativeElement.animate({
            opacity: 0,
            duration: 3000,
            iterations: 5
        })
        .then(() => console.log('ANIMAZIONE FINITA'))
        .catch(() => console.log('ERRORE ANIMAZIONE'));
    }
}
