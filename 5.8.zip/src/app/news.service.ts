import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
    API = 'https://newsapi.org/v2';
    API_KEY = 'b5b3e9c4a32d423e8b0da4c13e21e90c';
    ENDPOINT = 'top-headlines';

    constructor(private http: HttpClient) { }

    getNews() {
        return this.http.get(`${this.API}/${this.ENDPOINT}?country=it&apiKey=${this.API_KEY}`);
    }
}
